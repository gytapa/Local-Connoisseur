@extends ('layouts.app')
@section ('content')
    <div class="transparent">
        <h1>You have successfully registered</h1>
        <a href="/home">Go back to home</a>
    </div>
@endsection