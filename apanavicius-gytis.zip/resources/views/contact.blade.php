@extends ('layouts.app')
@section ('content')
    <div class="transparent">
        <div class="row">
            <div class="col">
                <h4 id="author"><b>Valdemaras Ambraziūnas</b></h4>
                <p>valdemaras.ambraziunas@ktu.lt</p>
            </div>
            <div class="col">
                <h4 id="author"><b>Gytis Apanavičius</b></h4>
                <p>gytis.apanavicius@ktu.lt</p>
            </div>
        </div>
    </div>
@endsection