@extends ('layouts.app')
@section ('content')
    <div class="transparent">
        <p id="about">Web page that you can use to find a place where you can grab a bite.
            Project uses Google Places API to get all of its places.
            User can write reviews about those places.
            Use our website to rate a place or find a place where you can hangout.</p>
    </div>
@endsection