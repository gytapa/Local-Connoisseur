<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h3>Edit your comment</h3>
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::open(['url' => 'editComment/submit']); ?>

        <?php echo e(Form::hidden('cid', $comment->id)); ?>

        <div class="form-group">
            <br>
            <?php echo e(Form::text('topic',$comment->tema,['class'=> 'form-control', 'placeholder' =>'Enter topic'])); ?>

            <br>
            <?php echo e(Form::textarea('text',$comment->tekstas,['class'=> 'form-control', 'placeholder' => 'Enter comment'])); ?>

        </div>
        <div>
            <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary'])); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>