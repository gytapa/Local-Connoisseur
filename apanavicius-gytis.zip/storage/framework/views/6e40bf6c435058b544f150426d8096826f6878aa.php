<div id="messages">
    <?php if(isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo e($_SESSION['success']); ?>

            <?php unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <?php if(isset($_SESSION['warning'])): ?>
        <div class="alert alert-warning">
            <?php echo e($_SESSION['warning']); ?>

            <?php unset($_SESSION['warning']); ?>
        </div>
    <?php endif; ?>

    <?php if(isset($_SESSION['danger'])): ?>
        <div class="alert alert-danger">
            <?php echo e($_SESSION['danger']); ?>

            <?php unset($_SESSION['danger']); ?>
        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>