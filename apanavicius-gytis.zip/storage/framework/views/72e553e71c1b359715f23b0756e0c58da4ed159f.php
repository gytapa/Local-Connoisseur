<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <h4>Block user: <?php echo e($user->pavarde); ?> <?php echo e($user->vardas); ?></h4>
        <?php echo Form::open(['url' => 'userlist/block/submitBlock']); ?>

        <?php echo e(Form::hidden('id', $user->id)); ?>

        <div class="form-group">
            <?php echo e(Form::label('reason', 'Reason')); ?>

            <?php echo e(Form::text('reason','',['class'=> 'form-control', 'placeholder' => 'Enter reason'])); ?>

            <br>
            <?php echo e(Form::label('date', 'Date of block expiration')); ?>

            <?php echo e(Form::date('date','',['class' => 'form-control'])); ?>

        </div>
        <div>
            <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary'])); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>