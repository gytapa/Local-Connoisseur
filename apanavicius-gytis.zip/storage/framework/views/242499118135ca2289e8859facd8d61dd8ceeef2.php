<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h1>My Lists</h1>
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(count($lists)>0): ?>
            <table class="table table-striped" id="clients-table">
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Created at</th>
                    <th></th>
                    <th></th>

                </tr>
                <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="data-item">
                        <td><?php echo e($list->pavadinimas); ?></td>
                        <td class="column-width"><?php echo e($list->aprasymas); ?></td>
                        <td><?php echo e($list->sukurimo_data); ?></td>
                        <td><a href="<?php echo e(url('lists/infoOfList/'.$list->id.'/')); ?>">More...</a></td>
                        <td><a href="<?php echo e(url('lists/deleteList/'.$list->id.'/')); ?>">Delete</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
        <br/>
        <a href="<?php echo e(url('lists/newList')); ?>">New List</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>