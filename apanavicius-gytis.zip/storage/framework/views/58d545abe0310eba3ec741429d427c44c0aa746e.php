<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h3>Critics list</h3>
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(isset($critics) && sizeof($critics) > 0): ?>
            <table class="table table-striped" id="critics-table">
                <tr>
                    <th>Email</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Last seen at</th>
                    <th>City</th>
                    <th>Address</th>
                    <th>Is confirmed</th>
                    <th>Block</th>
                </tr>
                <?php $__currentLoopData = $critics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $critic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="data-item">
                        <td><?php echo e($critic->el_pastas); ?></td>
                        <td><?php echo e($critic->vardas); ?></td>
                        <td><?php echo e($critic->pavarde); ?></td>
                        <td><?php echo e($critic->paskutinis_prisijungimas); ?></td>
                        <td><?php echo e($critic->miestas); ?></td>
                        <td><?php echo e($critic->adresas); ?></td>
                        <?php if($critic->ar_patvirtinta == 1): ?>
                            <td>Yes</td>
                        <?php else: ?>
                            <td>No</td>
                        <?php endif; ?>
                        <?php if($critic->blokas->count() > 0): ?>
                            <?php if(strtotime($critic->blokas->first()->laikas) > strtotime('now')): ?>
                                <td>User is already blocked <a href="<?php echo e(url('userlist/unblock/'.$critic->id.'/')); ?>">Unblock</a></td>
                            <?php else: ?>
                                <td><a href="<?php echo e(url('userlist/block/'.$critic->id.'/')); ?>">Block</a></td>
                            <?php endif; ?>
                        <?php else: ?>
                            <td><a href="<?php echo e(url('userlist/block/'.$critic->id.'/')); ?>">Block</a></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>There are no registered critics in the system</p>
                <?php endif; ?>
            </table>
            <h3>Users list</h3>
            <?php if(isset($users) && sizeof($users) > 0): ?>
                <table class="table table-striped" id="users-table">
                    <tr>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Surname</th>
                        <th>Last seen at</th>
                        <th>City</th>
                        <th>Address</th>
                        <th>Block</th>
                    </tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="data-item">
                            <td><?php echo e($user->el_pastas); ?></td>
                            <td><?php echo e($user->vardas); ?></td>
                            <td><?php echo e($user->pavarde); ?></td>
                            <td><?php echo e($user->paskutinis_prisijungimas); ?></td>
                            <td><?php echo e($user->miestas); ?></td>
                            <td><?php echo e($user->adresas); ?></td>
                            <?php if($user->blokas->count() > 0): ?>
                                <?php if(strtotime($user->blokas->first()->laikas) > strtotime('now')): ?>
                                    <td>User is already blocked <a href="<?php echo e(url('userlist/unblock/'.$user->id.'/')); ?>">Unblock</a></td>
                                <?php else: ?>
                                    <td><a href="<?php echo e(url('userlist/block/'.$user->id.'/')); ?>">Block</a></td>
                                <?php endif; ?>
                            <?php else: ?>
                                <td><a href="<?php echo e(url('userlist/block/'.$user->id.'/')); ?>">Block</a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p>There are no registered users in the system</p>
                    <?php endif; ?>
                </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>