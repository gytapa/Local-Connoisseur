<div class="col comment-column comment-margin">
    <ul class="list-group">
        <li class="list-group-item borderless" id="topic"><b><?php echo e($comment->tema); ?></b></li>
        <li class="list-group-item borderless"
            id="sender"><?php echo e($comment->user->vardas); ?> <?php echo e($comment->user->pavarde); ?></li>
        <li class="list-group-item borderless" id="date"><?php echo e($comment->laikas); ?></li>
        <?php
            $positive = 0;
            $negative = 0;
        ?>
        <?php $__currentLoopData = $comment->komentaro_vertinimas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                if($evaluation->vertinimas == 1){
                    $positive +=1;
                }
                else{
                    $negative +=1;
                }
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item borderless" id="evaluation"><span
                    id="evspan"><?php echo e($positive); ?></span><a class="upvote"
                                                       href="<?php echo e(url('infoOfPlace/evaluate/'.$comment->id.'/1/'.$place->id.'/')); ?>"></a><span
                    id="evspan"><?php echo e($negative); ?></span><a class="downvote"
                                                       href="<?php echo e(url('infoOfPlace/evaluate/'.$comment->id.'/-1/'.$place->id.'/')); ?>"></a>
        </li>
        <li class="list-group-item borderless" id="text"><?php echo e($comment->tekstas); ?></li>
        <?php if(isset($_SESSION['user']) && $_SESSION['user']->id == $comment->fk_VARTOTOJASid): ?>
            <li class="list-group-item borderless" id="actions"><a
                        href="<?php echo e(url('deleteComment/'.$comment->id.'/')); ?>">Delete</a>&nbsp;&nbsp;&nbsp;<a
                        href="<?php echo e(url('editComment/'.$comment->id.'/')); ?>">Edit</a></li>
        <?php elseif(isset($_SESSION['user']) && $_SESSION['user']->role == 0): ?>
            <li class="list-group-item borderless" id="actions"><a
                        href="<?php echo e(url('deleteComment/'.$comment->id.'/')); ?>">Delete</a></li>
        <?php endif; ?>
    </ul>
</div>