<?php $__env->startSection('content'); ?>
<div id="home-message" class="center">
    <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <h1>Quickly Find a Place To Eat</h1>
    <p>Use our search engine to find yourself a dining place.
    You can use our filters to find <br>a place that is perfect for your needs of eating.</p>
    <a href="search" id="home-button"><span>Find a Place</span></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>