<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <p id="about">Web page that you can use to find a place where you can grab a bite.
            Project uses Google Places API to get all of its places.
            User can write reviews about those places.
            Use our website to rate place or find a place where you can hangout.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>