<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h1>Critics, that need approval by admin</h1>
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <table class="table" id="confirmUsersTable">
            <tr>
                <th>Critics waiting for confirmation</th>
                <th>Uploaded documents</th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->vardas); ?> <?php echo e($user->pavarde); ?></td>
                    <td>
                        <?php if($user->sertifikatas->count() > 0): ?>
                            <?php $__currentLoopData = $user->sertifikatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('userpage/download/'.$certification->pavadinimas.'/')); ?>"><?php echo e($certification->pavadinimas); ?></a>
                                <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                    <td><a href="/confirm/<?php echo e($user->id); ?>">Confirm critic</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>