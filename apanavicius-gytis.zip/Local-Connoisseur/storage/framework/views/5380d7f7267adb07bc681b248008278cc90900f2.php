<?php $__env->startSection('content'); ?>
    <div class="white">
        <?php if(!empty($place)): ?>
            <div class="container">
                <div class="row">
                    <div class="col">
                        <img id="list-img" src="<?php echo e($place['nuotrauka']); ?>"
                             alt="No image available">
                    </div>
                    <div class="col align-left">
                        <h3><?php echo e($place->pavadinimas); ?></h3>
                        <?php
                            $suma = 0;

                        foreach($place->vietos_vertinimas as $evaluation)
                                $suma += $evaluation->vertinimas;
                        $result = 0;
                        if($suma > 0)
                        $result = $suma/$place->vietos_vertinimas->count();
                        $result = number_format((float)$result, 2, '.', '');
                        ?>
                        <p><?php echo e($result); ?>/5.00 <span class="blue">&#9733;</span></p>
                        <p>Cheap</p>
                        <p><?php echo e($place->adresas); ?></p>
                        <p>Get directions</p>
                    </div>
                    <div class="col">
                        <br>
                        <img height="150px" width="400px"
                             src="https://cnet2.cbsistatic.com/img/H_zPLL8-QTZOLxJvgHQ1Jkz0EgY=/830x467/2013/07/10/f0bcef02-67c2-11e3-a665-14feb5ca9861/maps_routemap.png"
                             alt="No image available">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <a href="<?php echo e(url('infoOfPlace/visited/'.$place->id.'/')); ?>">I have visited this place</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="rating">
                            <a href="<?php echo e(url('places/evaluate/'.$place->id.'/5/')); ?>"><span>☆</span></a>
                            <a href="<?php echo e(url('places/evaluate/'.$place->id.'/4/')); ?>"><span>☆</span></a>
                            <a href="<?php echo e(url('places/evaluate/'.$place->id.'/3/')); ?>"><span>☆</span></a>
                            <a href="<?php echo e(url('places/evaluate/'.$place->id.'/2/')); ?>"><span>☆</span></a>
                            <a href="<?php echo e(url('places/evaluate/'.$place->id.'/1/')); ?>"><span>☆</span></a>
                        </div>
                    </div>
                </div>
            </div>
            <div id="comments">
                <div class="container">
                    <?php if(isset($success)): ?>
                        <div class="alert alert-success">
                            <?php echo e($success); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col">
                            <?php echo $__env->make('include.commentcomponent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                    <?php if(count($comments)>0): ?>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col comment-column comment-margin">
                                <ul class="list-group">
                                    <li class="list-group-item borderless" id="topic"><b><?php echo e($comment->tema); ?></b></li>
                                    <li class="list-group-item borderless"
                                        id="sender"><?php echo e($comment->user->vardas); ?> <?php echo e($comment->user->pavarde); ?></li>
                                    <li class="list-group-item borderless" id="date"><?php echo e($comment->laikas); ?></li>
                                    <?php
                                        $positive = 0;
                                        $negative = 0;
                                    ?>
                                    <?php $__currentLoopData = $comment->komentaro_vertinimas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            if($evaluation->vertinimas == 1){
                                                $positive +=1;
                                            }
                                            else{
                                                $negative +=1;
                                            }
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item borderless" id="evaluation"><span
                                                id="evspan"><?php echo e($positive); ?></span><a class="upvote"
                                                                                   href="<?php echo e(url('infoOfPlace/evaluate/'.$comment->id.'/1/'.$place->id.'/')); ?>"></a><span
                                                id="evspan"><?php echo e($negative); ?></span><a class="downvote"
                                                                                   href="<?php echo e(url('infoOfPlace/evaluate/'.$comment->id.'/-1/'.$place->id.'/')); ?>"></a>
                                    </li>
                                    <li class="list-group-item borderless" id="text"><?php echo e($comment->tekstas); ?></li>
                                    <?php if(isset($_SESSION['user']) && $_SESSION['user']->id == $comment->fk_VARTOTOJASid): ?>
                                        <li class="list-group-item borderless" id="actions"><a
                                                    href="<?php echo e(url('deleteComment/'.$comment->id.'/')); ?>">Delete</a>&nbsp;&nbsp;&nbsp;<a
                                                    href="<?php echo e(url('editComment/'.$comment->id.'/')); ?>">Edit</a></li>
                                    <?php elseif(isset($_SESSION['user']) && $_SESSION['user']->role == 0): ?>
                                        <li class="list-group-item borderless" id="actions"><a
                                                    href="<?php echo e(url('deleteComment/'.$comment->id.'/')); ?>">Delete</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col comment-margin">
                            <p>There is no comments at the moment.</p>
                        </div>
                    <?php endif; ?>
                </div>

            </div>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>