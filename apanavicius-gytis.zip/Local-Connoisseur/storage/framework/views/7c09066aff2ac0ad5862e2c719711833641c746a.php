<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h3>Edit description about <?php echo e($addedPlace->lankytina_vietum->pavadinimas); ?> at list <?php echo e($addedPlace->sarasa->pavadinimas); ?></h3>
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::open(['url' => 'lists/infoOfList/submitNewPlaceDesc']); ?>

        <?php echo e(Form::hidden('id', $addedPlace->id)); ?>

        <div class="form-group">
            <?php echo e(Form::label('description', 'Description')); ?>

            <?php echo e(Form::textarea('description',$addedPlace->aprasymas,['class'=> 'form-control', 'placeholder' => 'Enter description of this place'])); ?>

        </div>
        <div>
            <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary'])); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>