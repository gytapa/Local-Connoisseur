<?php $__env->startSection('content'); ?>
    <div class="white">
        <?php if(!empty($place)): ?>
            <div class="container">
                <div class="row">
                    <div class="col">
                        <img id="list-img" src="<?php echo e($place['nuotrauka']); ?>"
                             alt="No image available">
                    </div>
                    <div class="col align-left">
                        <h3><?php echo e($place->pavadinimas); ?></h3>
                        <?php
                            $suma = 0;

                        foreach($place->vietos_vertinimas as $evaluation)
                                $suma += $evaluation->vertinimas;
                        $result = 0;
                        if($suma > 0)
                        $result = $suma/$place->vietos_vertinimas->count();
                        $result = number_format((float)$result, 2, '.', '');
                        ?>
                        <p><?php echo e($result); ?>/5.00 <span class="blue">&#9733;</span></p>
                        <p><?php echo e($place->adresas); ?></p>
                        <a href="https://www.google.com/maps/search/?api=1&query=<?php echo e($place['pavadinimas']); ?>"
                           class="card-text" target="_blank">Get Directions</a>
                    </div>
                    <div class="col">
                        <br>

                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <a href="<?php echo e(url('infoOfPlace/visited/'.$place->id.'/')); ?>">I have visited this place</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <a href="<?php echo e(url('infoOfPlace/addToList/'.$place->id.'/')); ?>">Add to list</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="rating">
                            <a id="star" href="<?php echo e(url('places/evaluate/'.$place->id.'/5/')); ?>"><span>☆</span></a>
                            <a id="star" href="<?php echo e(url('places/evaluate/'.$place->id.'/4/')); ?>"><span>☆</span></a>
                            <a id="star" href="<?php echo e(url('places/evaluate/'.$place->id.'/3/')); ?>"><span>☆</span></a>
                            <a id="star" href="<?php echo e(url('places/evaluate/'.$place->id.'/2/')); ?>"><span>☆</span></a>
                            <a id="star" href="<?php echo e(url('places/evaluate/'.$place->id.'/1/')); ?>"><span>☆</span></a>
                        </div>
                    </div>
                </div>
            </div>
            <div id="comments">
                <div class="container">
                    <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                        <div class="col">
                            <?php echo $__env->make('include.commentcomponent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                    <?php if(count($comments)>0): ?>
                        <p id="commentsSplit">Critics reviews</p>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($comment->user->ar_patvirtinta): ?>
                                <?php echo $__env->make('include.commentsBlock', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <p id="commentsSplit">Users reviews</p>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$comment->user->ar_patvirtinta): ?>
                                <?php echo $__env->make('include.commentsBlock', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col comment-margin">
                            <p>There is no comments at the moment.</p>
                        </div>
                    <?php endif; ?>
                </div>

            </div>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>