<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h1>Visited places</h1>
        <?php if(count($visitedPlaces)>0): ?>
            <table class="table table-striped" id="visitedPlaces-table">
                <tr>
                    <th>Title</th>
                    <th>Address</th>
                    <th>Date</th>
                    <th>Comment</th>
                </tr>
                <?php $__currentLoopData = $visitedPlaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="data-item">
                        <td><?php echo e($place->lankytina_vietum->pavadinimas); ?></td>
                        <td><?php echo e($place->lankytina_vietum->adresas); ?></td>
                        <td><?php echo e($place->data); ?></td>
                        <td class="column-width"><?php echo e($place->komentaras); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>