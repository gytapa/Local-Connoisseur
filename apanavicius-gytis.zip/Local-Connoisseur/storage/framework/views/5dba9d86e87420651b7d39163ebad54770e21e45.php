<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <div class="row">
            <div class="col">
                <h4 id="author"><b>Valdemaras Ambraziūnas</b></h4>
                <p>valdemaras.ambraziunas@ktu.lt</p>
            </div>
            <div class="col">
                <h4 id="author"><b>Gytis Apanavičius</b></h4>
                <p>gytis.apanavicius@ktu.lt</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>