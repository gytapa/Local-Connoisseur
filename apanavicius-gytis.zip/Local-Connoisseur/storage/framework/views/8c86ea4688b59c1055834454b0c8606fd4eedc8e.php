<?php $__env->startSection('content'); ?>
    <div class="transparent">
    <h1>You have been successfully Logged in</h1>

    <a href="/home">Go back to home</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>