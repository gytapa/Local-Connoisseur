<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h3>Add to list</h3>
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(isset($_SESSION['user'])): ?>
            <?php if(count($lists) > 0): ?>
                <?php echo Form::open(['url' => 'infoOfPlace/addToList/add']); ?>

                <?php echo e(Form::label('list', 'Select list')); ?>

              <br>
                <select name="list" class="selectpicker">
                    <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                         echo "<option value=".$list['id'].">".$list['pavadinimas']."</option>";
                         ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo e(Form::hidden('pid', $place->id)); ?>

                 <br>
                <?php echo e(Form::label('description', 'Description')); ?>

                <?php echo e(Form::textarea('description','',['class'=> 'form-control column-width', 'placeholder' => 'Enter your description'])); ?>

                <br>
                <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>



            <?php else: ?>
                <p>You don't have any lists.</p>
                <a href="<?php echo e(url('lists/newList')); ?>">Click here and create one</a>
            <?php endif; ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>