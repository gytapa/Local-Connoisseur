<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h1>Places</h1>
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(count($places)>0): ?>
            <table class="table table-striped" id="critics-table">
                <tr>
                    <th>Title</th>
                    <th>Address</th>
                    <th>Evaluation</th>
                    <th></th>

                </tr>
                <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="data-item">
                        <td><?php echo e($place->pavadinimas); ?></td>
                        <td><?php echo e($place->adresas); ?></td>
                        <td><a href="<?php echo e(url('infoOfPlace/'.$place->id.'/')); ?>">More...</a></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>