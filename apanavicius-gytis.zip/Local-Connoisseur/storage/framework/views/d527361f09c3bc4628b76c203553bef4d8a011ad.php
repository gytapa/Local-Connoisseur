<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h3>Add Document</h3>
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(isset($_SESSION['user']) && $_SESSION['user']->role == 1 && $_SESSION['user']->ar_patvirtinta == 0): ?>
            <?php echo Form::open( [ 'url' =>  'userpage/addDocument/submit' , 'method' => 'post', 'files' => true ] ); ?>

            <?php echo e(Form::label('file', 'Upload file')); ?>

            <br>
            <?php echo e(Form::file('uploadedFile')); ?>

            <br>
            <?php echo e(Form::label('description', 'Description')); ?>

            <?php echo e(Form::textarea('description','',['class'=> 'form-control column-width', 'placeholder' => 'Enter your description'])); ?>

            <br>
            <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>