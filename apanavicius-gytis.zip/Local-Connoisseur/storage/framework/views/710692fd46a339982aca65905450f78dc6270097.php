<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <?php if($_SESSION['user']->role == 1): ?>
            <?php if($_SESSION['user']->ar_patvirtinta == 0): ?>
                <?php if(count($certification)>0): ?>
                    <div class="alert alert-warning">
                        <p>Your status as a critic still waiting for approval. Please add your certificate and/or other
                            documents in order to accelare the procces. If u already did that please be patient.</p>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger">
                        <p>In order to be approved as a critic you need to upload at least one document proving your
                            status.</p>
                    </div>
                <?php endif; ?>
                <a href="/userpage/addDocument">Add document</a>
            <?php else: ?>
                <div class="alert alert-success">
                    <p>Your status as a critic is approved.</p>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <h1>Hello,<?php echo e($user->vardas); ?> <?php echo e($user->pavarde); ?></h1>
        <h3>City: <?php echo e($user->miestas); ?></h3>
        <h3>Address: <?php echo e($user->adresas); ?></h3>

        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if($_SESSION['user']->role == 1 && count($certification)>0): ?>
            <table class="table" id="documentsTable">
                <tr>
                    <th>Documents</th>
                </tr>
                <?php $__currentLoopData = $certification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(url('userpage/download/'.$item->pavadinimas.'/')); ?>"><?php echo e($item->pavadinimas); ?></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>