<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <h4><?php echo e($name); ?></h4>
        <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::open(['url' => 'infoOfPlace/submitVisited']); ?>

    <?php echo e(Form::hidden('pid', $pid)); ?>

    <div class="form-group">
        <?php echo e(Form::label('comment', 'Comment')); ?>


        <?php echo e(Form::textarea('comment','',['class'=> 'form-control', 'placeholder' => 'Enter comment about your experience in this place'])); ?>

        <br>
        <?php echo e(Form::label('date', 'Date of visit')); ?>

        <?php echo e(Form::date('date','',['class' => 'form-control'])); ?>

    </div>
    <div>
        <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary'])); ?>

    </div>
    <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>