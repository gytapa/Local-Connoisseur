<?php $__env->startSection('content'); ?>
    <div class="transparent">
        <?php if(!empty($list)): ?>
            <h3><?php echo e($list->pavadinimas); ?></h3>
            <p class="list-info"><?php echo e($list->aprasymas); ?></p>
            <p class="list-info">Created at: <?php echo e($list->sukurimo_data); ?></p>
            <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php if($list->itraukta_vieta->count() > 0): ?>
                <h4>Places in this list:</h4>
                <table class="table table-striped" id="listPlaces">
                    <tr>
                        <th>Title</th>
                        <th>Address</th>
                        <th>Description</th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                    <?php $__currentLoopData = $list->itraukta_vieta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addedPlace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="data-item">
                            <td><?php echo e($addedPlace->lankytina_vietum->pavadinimas); ?></td>
                            <td><?php echo e($addedPlace->lankytina_vietum->adresas); ?></td>
                            <td class="listPlacesDesc"><?php echo e($addedPlace->aprasymas); ?></td>
                            <td><a href="<?php echo e(url('infoOfPlace/'.$addedPlace->lankytina_vietum->id.'/')); ?>">More about this place</a></td>
                            <td><a href="<?php echo e(url('/lists/infoOfList/editAddedPlace/'.$addedPlace->id.'/')); ?>">Change description</a></td>
                            <td><a href="<?php echo e(url('/lists/infoOfList/deleteAddedPlace/'.$addedPlace->id.'/')); ?>">Remove</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            <?php else: ?>
                <p class="list-info">There is no places included in this list.</p>
            <?php endif; ?>
        <?php else: ?>
            <p>List do not exists</p>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>